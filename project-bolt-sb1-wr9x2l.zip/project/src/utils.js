// Utility functions
export function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

export function createDataAugmentation(text) {
  // Implement data augmentation logic here
  return [text];
}