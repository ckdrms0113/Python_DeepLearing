import { pipeline } from 'transformers.js';
import { MODEL_CONFIG } from '../config/modelConfig.js';

export class TeacherModel {
  constructor() {
    this.model = null;
    this.config = MODEL_CONFIG.teacher;
  }

  async init() {
    try {
      this.model = await pipeline('text-classification', this.config.name);
    } catch (error) {
      throw new Error(`TeacherModel 초기화 실패: ${error.message}`);
    }
  }

  async evaluateQuestion(question, context) {
    if (!this.model) {
      await this.init();
    }
    
    try {
      const prompt = `문맥: ${context}\n질문: ${question}\n품질 점수:`;
      const output = await this.model(prompt);
      
      return this.normalizeScore(output[0].score);
    } catch (error) {
      throw new Error(`질문 평가 실패: ${error.message}`);
    }
  }

  normalizeScore(score) {
    return 1 / (1 + Math.exp(-score));
  }
}