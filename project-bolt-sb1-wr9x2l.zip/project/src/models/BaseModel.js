export class BaseModel {
  constructor(config = {}) {
    this.config = config;
  }

  async init() {
    try {
      await this.initializeModel();
    } catch (error) {
      throw new Error(`모델 초기화 실패: ${error.message}`);
    }
  }

  async initializeModel() {
    // Implement in derived classes
    throw new Error('initializeModel must be implemented');
  }
}