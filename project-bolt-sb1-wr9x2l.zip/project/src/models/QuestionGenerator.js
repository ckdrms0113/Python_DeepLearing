import { NlpManager } from 'node-nlp';
import { extractKeyTerms, generatePatterns } from '../utils/textUtils.js';

export class QuestionGenerator {
  constructor() {
    this.nlp = new NlpManager({ languages: ['ko'] });
    this.patterns = generatePatterns();
  }

  async init() {
    await this.nlp.train();
  }

  generateQuestion(context) {
    const keyTerms = extractKeyTerms(context);
    const pattern = this.selectPattern();
    return this.createQuestion(keyTerms[0] || '이것', pattern);
  }

  selectPattern() {
    return this.patterns[Math.floor(Math.random() * this.patterns.length)];
  }

  createQuestion(term, pattern) {
    return `${term}${pattern.particle} ${pattern.template}`;
  }

  evaluateQuestion(question, context) {
    const relevanceScore = this.calculateRelevance(question, context);
    const lengthScore = this.calculateLengthScore(question);
    return (relevanceScore + lengthScore) / 2;
  }

  calculateRelevance(question, context) {
    const contextTerms = extractKeyTerms(context);
    const questionTerms = extractKeyTerms(question);
    const commonTerms = contextTerms.filter(term => 
      questionTerms.some(qTerm => qTerm.includes(term))
    );
    return commonTerms.length / contextTerms.length;
  }

  calculateLengthScore(question) {
    const idealLength = 20;
    const currentLength = question.length;
    return Math.min(1, Math.max(0.5, 1 - Math.abs(currentLength - idealLength) / idealLength));
  }
}