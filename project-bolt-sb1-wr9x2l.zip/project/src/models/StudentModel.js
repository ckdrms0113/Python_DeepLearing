import { pipeline } from 'transformers.js';
import { MODEL_CONFIG } from '../config/modelConfig.js';

export class StudentModel {
  constructor() {
    this.generator = null;
    this.config = MODEL_CONFIG.student;
  }

  async init() {
    try {
      this.generator = await pipeline('text-generation', this.config.name);
    } catch (error) {
      throw new Error(`StudentModel 초기화 실패: ${error.message}`);
    }
  }

  async generateQuestion(context, maxLength = this.config.maxLength) {
    if (!this.generator) {
      await this.init();
    }
    
    try {
      const prompt = `문맥: ${context}\n질문:`;
      const output = await this.generator(prompt, {
        max_length: maxLength,
        num_return_sequences: 1,
        temperature: this.config.temperature,
        top_p: this.config.topP,
        do_sample: true
      });

      const generatedText = output[0].generated_text;
      return this.extractQuestion(generatedText);
    } catch (error) {
      throw new Error(`질문 생성 실패: ${error.message}`);
    }
  }

  extractQuestion(text) {
    const questionPart = text.split('질문:')[1]?.trim();
    return questionPart || text;
  }
}