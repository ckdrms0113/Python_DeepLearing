import { StudentModel } from './models/StudentModel.js';
import { TeacherModel } from './models/TeacherModel.js';

export class QuestionGenerator {
  constructor() {
    this.student = new StudentModel();
    this.teacher = new TeacherModel();
    this.questionHistory = [];
  }

  async init() {
    await Promise.all([
      this.student.init(),
      this.teacher.init()
    ]);
  }

  async generateAndEvaluate(context) {
    const question = await this.student.generateQuestion(context);
    const score = await this.teacher.evaluateQuestion(question, context);

    const result = {
      context,
      question,
      qualityScore: score
    };

    this.questionHistory.push(result);
    return result;
  }
}