import Hangul from 'hangul-js';

export function extractKeyTerms(text) {
  const stopWords = ['은', '는', '이', '가', '을', '를', '의', '에', '와', '과'];
  return text
    .split(/[\s,\.]+/)
    .filter(term => 
      term.length > 1 && 
      !stopWords.includes(term) &&
      !term.match(/^[0-9]+$/)
    );
}

export function generatePatterns() {
  return [
    { type: '정의', particle: '은(는)', template: '무엇입니까?' },
    { type: '설명', particle: '을(를)', template: '어떻게 설명할 수 있습니까?' },
    { type: '특징', particle: '의', template: '주요 특징은 무엇입니까?' },
    { type: '예시', particle: '의', template: '대표적인 예시는 무엇입니까?' },
    { type: '방법', particle: '은(는)', template: '어떤 방식으로 작동합니까?' }
  ];
}

export function normalizeKoreanText(text) {
  return Hangul.assemble(Hangul.disassemble(text));
}