import { QuestionGenerator } from './models/QuestionGenerator.js';

async function main() {
  try {
    console.log('질문 생성기 초기화 중...');
    const generator = new QuestionGenerator();
    await generator.init();

    const context = "인공지능은 컴퓨터 과학의 한 분야로, 기계가 인간의 지능을 모방하도록 하는 기술입니다.";
    
    console.log('\n원본 문맥:', context);
    console.log('\n질문 생성 시작...\n');

    for (let i = 0; i < 3; i++) {
      console.log(`시도 ${i + 1}`);
      console.log('-'.repeat(50));

      const question = generator.generateQuestion(context);
      const score = generator.evaluateQuestion(question, context);
      
      console.log('생성된 질문:', question);
      console.log('품질 점수:', score.toFixed(4));
      console.log('-'.repeat(50), '\n');

      if (score > 0.8) {
        console.log('높은 품질의 질문이 생성되었습니다!');
        break;
      }
    }

  } catch (error) {
    console.error('오류 발생:', error.message);
    process.exit(1);
  }
}

main();