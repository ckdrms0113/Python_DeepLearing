export const MODEL_CONFIG = {
  student: {
    name: 'skt/ko-gpt-trinity-1.2B-v0.5',
    maxLength: 100,
    temperature: 0.7,
    topP: 0.9
  },
  teacher: {
    name: 'klue/roberta-large'
  }
};