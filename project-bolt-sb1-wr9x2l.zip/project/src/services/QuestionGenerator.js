import { StudentModel } from '../models/StudentModel.js';
import { TeacherModel } from '../models/TeacherModel.js';
import { createDataAugmentation } from '../utils/textUtils.js';

export class QuestionGenerator {
  constructor() {
    this.student = new StudentModel();
    this.teacher = new TeacherModel();
    this.questionHistory = [];
  }

  async init() {
    try {
      await Promise.all([
        this.student.init(),
        this.teacher.init()
      ]);
    } catch (error) {
      throw new Error(`QuestionGenerator 초기화 실패: ${error.message}`);
    }
  }

  async generateAndEvaluate(context) {
    try {
      const augmentedContexts = await createDataAugmentation(context);
      const results = await Promise.all(
        augmentedContexts.map(async (ctx) => {
          const question = await this.student.generateQuestion(ctx);
          const score = await this.teacher.evaluateQuestion(question, ctx);

          const result = {
            context: ctx,
            question,
            qualityScore: score,
            timestamp: new Date().toISOString()
          };

          this.questionHistory.push(result);
          return result;
        })
      );

      return results[0]; // 원본 컨텍스트의 결과 반환
    } catch (error) {
      throw new Error(`질문 생성 및 평가 실패: ${error.message}`);
    }
  }

  getHistory() {
    return this.questionHistory;
  }
}